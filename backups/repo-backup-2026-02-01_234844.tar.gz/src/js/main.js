// TechnoDocs - Point d'entrée principal
// Ce fichier est le point d'entrée unique pour Vite

import './components.js';
import './app.js';
